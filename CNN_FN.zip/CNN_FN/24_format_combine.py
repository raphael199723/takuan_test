import numpy as np
import pandas as pd
import sys
import os
import math

data_path='ideal_bl521_20210531_train/tmp/'
data_path1='ideal_bl521_20210531_train/tmp1/'
data_name_list=[x for x in os.listdir(data_path)]
data_name_list1=[x for x in os.listdir(data_path1)]

def pdu_data_preprocessing(lines,ratio):
    cnt = 0
    tmp_sum = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    out = []
    for i in range(len(lines)):
        tmp = lines[i].split(" ")[:20]
        cnt = cnt + 1
        tmp_sum = [(tmp_sum[i] + int(tmp[i])) for i in range(20)]
       # print("tmp: ",tmp,"tmp_sum: ",tmp_sum)
        if cnt == ratio:
            cnt = 0
            out.append([round(tmp_sum[i]/ratio) for i in range(20)])
            tmp_sum = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    return out

if __name__ == '__main__':
    count, c = 0, 1
    for y,y1 in zip(sorted(data_name_list),sorted(data_name_list1)):
        all_data1 = []
        #print(y1)
        fp1 = open(data_path1+y1,"r")
        lines1 = fp1.readlines()
        lines1_length = len(lines1)
        #print(lines1_length)

        all_data = []
        #print(y)
        fp = open(data_path+y,"r")
        lines = fp.readlines()
        lines_length = len(lines)
        #print(lines_length)
        ratio = lines1_length/lines_length
        tmp1 = pdu_data_preprocessing(lines1,int(ratio))
        #print(ratio)
        attenuation = []
        for i in range(len(lines)):
            attenuation.append(lines[i].replace(" ",",").replace("\n","").split(','))
        attenuation = np.array(attenuation)
        #print("1: ",attenuation[2])
        x_axis, y_axis = [], []
        label = [[0.1,580],[0.1,400],[0.1,200],[136.2,90],[136.2,180],[272,200],[272,400],[272,580]]
        r = label[count]
        count += 1
        for i in range(len(attenuation)):
#            print(int(attenuation[i][0]))
            if int(attenuation[i][0]) == 0:
                x_axis.append(0)             
                y_axis.append(0)
            else:
                try:
                    x_axis.append(math.log(c*int(attenuation[i-1][0])/int(attenuation[i][0]))/math.log(r[0]))
                    y_axis.append(math.log(c*int(attenuation[i-1][0])/int(attenuation[i][0]))/math.log(r[1]))
                except:
                    x_axis.append(0)
                    y_axis.append(0)    

        #print(r[0]**int(attenuation[i][1]))
#            print(int(attenuation[i][0]))
#        print(count)
        for i in range(len(lines)):
            tmp = lines[i].replace(" ","\t").replace("\n","")
            all_data.append(tmp+"\t"+str(x_axis[i])+"\t"+str(y_axis[i])+"\t"+str(tmp1[i]).replace("[","").replace("]","").replace(",","\t").replace(" ",""))
        fp.close()
        fp1.close()
        out = pd.DataFrame(all_data)
    
        if not os.path.exists("format_combine"):
            os.mkdir("format_combine")
        if not os.path.exists("format_combine/train"):
            os.mkdir("format_combine/train")
        if not os.path.exists("format_combine/test"):
            os.mkdir("format_combine/test")


        out[:900].to_csv("format_combine/train/format_pdu_"+y+".csv",index = False,header = False) 
        out[900:].to_csv("format_combine/test/format_pdu_"+y+".csv",index = False,header = False) 
