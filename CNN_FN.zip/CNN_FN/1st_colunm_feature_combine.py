import numpy as np
import pandas as pd
import sys
import os
data_path='ideal_bl521_20210531_train/tmp/'
data_name_list=[x for x in os.listdir(data_path)]


if __name__ == '__main__':
    for y in (sorted(data_name_list)):
        all_data = []
        fp = open(data_path+y,"r")
        lines = fp.readlines()
        lines_length = len(lines)
        #print(y)
        for i in range(len(lines)):
            tmp = ((str(lines[i][0])+str(lines[i][1]))).replace(" ","\t").replace("\n","")
            #tmp = ((str(lines[i][3])+str(lines[i][4]))).replace(" ","\t").replace("\n","")
            print("lenght line: ",tmp)
            all_data.append((tmp).replace("[","").replace("]","").replace(",","\t").replace(" ",""))
            #print("lenght line: ",tmp)
        fp.close()
        out = pd.DataFrame(all_data)
    
        if not os.path.exists("format_combine"):
            os.mkdir("format_combine")
        if not os.path.exists("format_combine/train"):
            os.mkdir("format_combine/train")
        if not os.path.exists("format_combine/test"):
            os.mkdir("format_combine/test")


        out[:900].to_csv("format_combine/train/format_pdu_"+y+".csv",index = False,header = False) 
        out[900:].to_csv("format_combine/test/format_pdu_"+y+".csv",index = False,header = False) 
