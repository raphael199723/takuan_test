import numpy as np
import pandas as pd
import sys
from tensorflow import keras
from tensorflow.keras import layers
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout,BatchNormalization,Conv1D
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.optimizers import RMSprop,Adam
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler ,MinMaxScaler
import os
 
path='format_combine/test/'
std_mean_value = np.array(pd.read_csv('format_combine/std_mean/std_mean_value.csv', na_filter = False, header = None))
feature_num = 25
slot_num = 8 
RP_number = 8 
#RP_num = [0,102,111,129,179,170,151]
def preprocessing(path=str, feature_num=int):
	csv_name_list=[x for x in os.listdir(path)]
	#print(csv_name_list)
	x_test = []
	y_label = []
	reg = []
	reg1 = []
	reg2 = []
	#RP_num = [0,17,18,22,30,28,25]
	RP_num = [0,105,140,374,105,515,162,188,347]
	for i in sorted(csv_name_list):
		x_test.append(np.array(pd.read_csv(path+i, na_filter = False, header = None))) # read_csv : read csv file; na_filter : whether detect missing value markers or not
		print(i)
		y_label.append(''.join([k for k in i if k.isdigit()]))
	for i in range(len(x_test)):
		for j in range(len(x_test[i])):
			tmp = str(x_test[i][j])
			#feature_num = len(tmp)
			reg.append(tmp.replace("['","").replace("']","").replace("\\t",",").split(','))
			if y_label[i] == '1':
				reg1.append('0, 580'.split(','))
				print("1")
			elif y_label[i] == '2':
				reg1.append('0, 400'.split(','))
				print("2")
			elif y_label[i] == '3':
				reg1.append('0, 200'.split(','))
				print("3")
			elif y_label[i] == '4':
				reg1.append('136.2, 90'.split(','))
				print("4")
			elif y_label[i] == '5':
				reg1.append('136.2, 180'.split(','))
				print("5")
			elif y_label[i] == '6':
				reg1.append('272, 200'.split(','))
			elif y_label[i] == '7':	
				reg1.append('272, 400'.split(','))
			else:
				reg1.append('272, 580'.split(','))
				print("6")
	print("check_len_reg:",len(reg))
	print("check_reg1:",reg1)
#	for j in range(len(reg)):
#			if j % 6 == 0 and j > 0:
#				reg2.append(reg1[j])
#				print('j: ',j)

	N = len(reg)
	#print('reg: ',len(reg))
	#print('reg1: ',len(reg1))
	#print('reg2: ',len(reg2))
	x_n_test = np.array(reg)
	y_n_label = np.array(reg1).reshape(N,2)

	print("xtest shape: ",x_n_test.shape)
	x_extract = np.empty([(len(x_n_test)-RP_number)*RP_number, feature_num])
	y_extract = np.empty([(len(x_n_test)-RP_number)*RP_number, 2])
	extract_count = 0
	ii_count = 0
	ii = 0
	print("x_ex shape: ",x_extract.shape)
	for i in range((len(x_n_test)-RP_number)*RP_number):
		for j in range(feature_num):
			if extract_count ==  RP_number:
				ii_count += 1
				ii = ii_count
				extract_count = 0
			x_extract[i,j] = x_n_test[ii,j]
		for jj in range(2):
			y_extract[i,jj] = y_n_label[ii,jj]
		extract_count += 1
		ii +=1

        #savetxt('check.csv',x_extract)#,delimeter=',')
        #np.set_printoptions(threshold=sys.maxsize)
	print("x_n_train: ",x_extract.shape)
	print("xlabel: ",x_extract[0])
	print("xlabel: ",x_extract[1])
	print("xlabel: ",x_extract[2])
	print("xlabel: ",x_extract[8])
	print("xlabel: ",x_extract[9])
	x_n_test = x_extract
	y_n_label = y_extract
	print("xtest:",len(x_n_test))
	print(y_n_label)
	print("y_n_label shape: ",y_n_label.shape)

	reg1 = np.empty([int(len(y_n_label)/RP_number), 2])
	reg1 = []
	print(y_n_label[1,0])
	for i in range(len(x_n_test)):
		if i%RP_number==0:
			reg1.append( y_n_label[i])
#       print(reg1)
	reg1 = np.array(reg1)
	print(reg1)
	y_n_label = np.array(reg1).reshape(int(len(y_n_label)/RP_number),2)

#	y_n_label = np.array(reg2).reshape(int(N/6),2) # N,2
	# print((x_n_test.dtype))
	# print((y_n_label.dtype))
	x_n_test = x_n_test.astype('float64') 
	y_n_label = y_n_label.astype('float64')

	print("x_n_test::::",x_n_test)
	N = len(x_n_test)
	# Standardization
	tmp = np.zeros([N, feature_num])

	for j in range(feature_num):
		#print("std_check: ",std_mean_value[0,j])
		#print("mean_check: ",std_mean_value[1,j])
		std_t = std_mean_value[0,j]
		mean_t = std_mean_value[1,j]
		for i in range(N): 
			tmp[i][j] = (x_n_test[i][j] - mean_t) / (std_t+1e-5)

	x_n_test = tmp#:840] #only use 1-840
	#print(len(x_n_test))
	#print('x_n_test[0]',x_n_test[0],';size:',len(x_n_test[0]))
	x_n_test = x_n_test.reshape(int(len(x_n_test)/RP_number),RP_number,feature_num,1) #B,W,H,Channel ; B*W=total num
	#print(y_n_label)
	#print("check shape before return x_n_test: ",x_n_test)
	return x_n_test, y_n_label, RP_num

def main():
	x_n_test, y_n_label, RP_num = preprocessing(path, feature_num)
	#print("check cntest: ",x_n_test)
	#print("check ynlabel ",len(y_n_label))
	model = keras.models.load_model('CNN.h5')
	predict_value = model.predict(x_n_test)
	#print(predict_value, np.sum(predict_value[1300]))
	ans = np.array([])
	RP1 = np.array([0, 580])
	RP2 = np.array([0, 400])
	RP3 = np.array([0, 580])
	RP4 = np.array([136.2, 90])
	RP5 = np.array([136.2, 180])
	RP6 = np.array([272, 200])
	RP7 = np.array([272, 400])
	RP8 = np.array([272, 580])
	print('len:',predict_value.shape[0])
	for i in range(predict_value.shape[0]):
		tmp=RP1*predict_value[i][0]+RP2*predict_value[i][1]+RP3*predict_value[i][2]+RP4*predict_value[i][3]+RP5*predict_value[i][4]+RP6*predict_value[i][5]+RP7*predict_value[i][6]+RP8*predict_value[i][7]
		if ans.shape[0] == 0:
			ans = np.array([tmp])
		else:
			ans = np.append(ans, tmp)
	#print((ans).reshape(-1,2)[0:20])
	#print(y_n_label.reshape(-1,2)[0:20])
	#print((ans).reshape(-1,2)[822:842])
	#print(y_n_label.reshape(-1,2)[822:842])
	out_pred_format = []
	out_label_format = []
	str1 = ','
	print("check ans: ",len(ans))
	for i in range((ans).reshape(-1,2).shape[0]):
		out_pred_format.append(str1.join( (ans.reshape(-1,2)[i]).astype('str') ))
		out_label_format.append(str1.join( (y_n_label.reshape(-1,2)[i]).astype('str') ))
	out = pd.DataFrame([out_pred_format,out_label_format]).T
	out.columns = ["ans","label"]
	out.to_csv('3in1_attenuation_ideal_slot_CNN_output_predict.csv',index = False)

	print("Out: ",out)
	
	
	model1 = keras.models.load_model('FN.h5')
	index = 0
	ans = np.array([])
	label = np.array([])
	for i in range(1,RP_number+1):
		index = index + RP_num[i]
		remove_num = RP_num[i] % slot_num
		print("check two: ",index-RP_num[i],index-remove_num)
		#print("len: ",len(np.array([out_pred_format[index-RP_num[i]:index-Remove_num]]).reshape(-1,1)))
		#tmp1 = np.array([out_pred_format[0:40]]).reshape(-1,slot_num)
		#print("check out__pred_format:", len(out_pred_format))
		tmp1 = np.array([out_pred_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)
		print("tmp1",len(tmp1))
		DNN_output_by_slot = np.array([])
		for j in range(tmp1.shape[0]):
			for k in range(RP_number):
				#print(tmp1[j][k])
				if DNN_output_by_slot.shape[0] == 0:
					DNN_output_by_slot = np.array([str(tmp1[j][k]).split(',')])
				else:
					DNN_output_by_slot = np.append(DNN_output_by_slot, [str(tmp1[j][k]).split(',')])
		DNN_output_by_slot = DNN_output_by_slot.astype('float64')
		#print(len(DNN_output_by_slot.reshape(-1,slot_num*2)))
		predict_value1 = model1.predict(DNN_output_by_slot.reshape(-1,slot_num*2))
		if ans.shape[0] == 0:
			ans = np.array([predict_value1])
		else:
			ans = np.append(ans, predict_value1)

		label_tmp = np.array([out_label_format[index-RP_num[i]:index-remove_num]]).reshape(-1,slot_num)[:,0]
		if label.shape[0] == 0:
			label = np.array([label_tmp])
		else:
			label = np.append(label, label_tmp)
	out_pred_format = []
	str1 = ','
	for i in range((ans).reshape(-1,2).shape[0]):
		out_pred_format.append(str1.join( (ans.reshape(-1,2)[i]).astype('str') ))
	out = pd.DataFrame([out_pred_format,label]).T
	out.columns = ["ans","label"]
	out.to_csv('3in1model__attenuation_ideal_slot_CNN_and_FN_output_predict.csv',index = False)

if __name__ == "__main__":
	main()
