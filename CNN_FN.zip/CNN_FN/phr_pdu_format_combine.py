import numpy as np
import pandas as pd
import sys
import os
data_path='ideal_bl521_20210531_train/tmp/'
data_path1='ideal_bl521_20210531_train/tmp1/'
data_name_list=[x for x in os.listdir(data_path)]
data_name_list1=[x for x in os.listdir(data_path1)]

def pdu_data_preprocessing(lines,ratio):
    cnt = 0
    tmp_sum = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    out = []
    for i in range(len(lines)):
        tmp = lines[i].split(" ")[:20]
        cnt = cnt + 1
        tmp_sum = [(tmp_sum[i] + int(tmp[i])) for i in range(20)]
        if cnt == ratio:
            cnt = 0
            out.append([round(tmp_sum[i]/ratio) for i in range(20)])
            tmp_sum = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
    return out

if __name__ == '__main__':
    for y,y1 in zip(sorted(data_name_list),sorted(data_name_list1)):
        all_data1 = []
        #print(y1)
        fp1 = open(data_path1+y1,"r")
        lines1 = fp1.readlines()
        lines1_length = len(lines1)
        #print(lines1_length)

        all_data = []
        #print(y)
        fp = open(data_path+y,"r")
        lines = fp.readlines()
        lines_length = len(lines)
        #print(lines_length)
        ratio = lines1_length/lines_length
        tmp1 = pdu_data_preprocessing(lines1,int(ratio))
        #print(ratio)
        for i in range(len(lines)):
            tmp = lines[i][0]+lines[i][1]
            all_data.append(tmp+"\t"+str(tmp1[i]).replace("[","").replace("]","").replace(",","\t").replace(" ",""))
        fp.close()
        fp1.close()
        out = pd.DataFrame(all_data)
    
        if not os.path.exists("format_combine"):
            os.mkdir("format_combine")
        if not os.path.exists("format_combine/train"):
            os.mkdir("format_combine/train")
        if not os.path.exists("format_combine/test"):
            os.mkdir("format_combine/test")


        out[:900].to_csv("format_combine/train/format_pdu_"+y+".csv",index = False,header = False) 
        out[900:].to_csv("format_combine/test/format_pdu_"+y+".csv",index = False,header = False) 
